// Filled in by the build system

#pragma once

#define TEST_WORLDDIR "/home/pi/minetest-5.4.0/src/unittest/test_world"
#define TEST_SUBGAME_PATH "/home/pi/minetest-5.4.0/src/unittest/../../games/devtest"
